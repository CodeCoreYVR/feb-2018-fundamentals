// what is the definition of a function?
// i have bodily functions.
// i am functional because i am healthy.
// process of actions, input and output.

// routine - repeat over and over and over...
// morning
// -wake up
// -have coffee
// -eat breakfast
// -brush our teeth
// -get changed
// -catch the bus
// -code

// 5 days a week
// monday, tues, wed, thur, fri

// -wake up
// -have juice
// -eat breakfast
// -brush our teeth
// -get changed
// -catch the bus
// -code

// -wake up
// -have juice
// -eat breakfast
// -brush our teeth
// -get changed
// -catch the bus
// -code

// -wake up
// -have juice
// -eat breakfast
// -brush our teeth
// -get changed
// -catch the bus
// -code

// -wake up
// -have juice
// -eat breakfast
// -brush our teeth
// -get changed
// -catch the bus
// -code

// 1. function keyword
// 2. function name
// 3. () <- parameters or arguments
// 4. {} <- instructions or block of code
// function functionName () {}
function morning() {
    console.log("wakeup");
    console.log("have juice");
    console.log("eat breakfast");
    console.log("brush teeth");
    console.log("catch bus");
    console.log("code");
}

// call, run or execute a function
// functionName with (); executes the function
morning();
morning();
morning();
morning();
morning();

let counter = 0;
while (counter < 5) {
    morning();
    counter++;
}
 
