// simple object
let mom = {
    name: "Maria",
    age: 68,
    child: "Jacob"
};

// attribute (property, key)
// attribute accessor
// get and set
// getter and setter
mom.age; // 68, getter
me.age = 69; // setter
delete me.age;

let mom = {
    name: "Maria",
    age: 68,
    children: ["Jacob", "Anthony", "John", "Theresa"],
    car: {}

    // child0: "Jacob",
    // child1: "Anthony",
    // child2: "John",
    // child3: "Theresa"
};

// who is mom's last child?
mom.children[3][0];


let mom = {
    name: "Maria",
    age: 68,
    children: ["Jacob", "Anthony", "John", "Theresa"]
    // child0: "Jacob",
    // child1: "Anthony",
    // child2: "John",
    // child3: "Theresa"
};

// who is mom's last child?
mom.children[3];
mom.children[3][0];

// mom is an Object
// mom.children is an Array
// mom.children[0] is a String
// mom.children[0][0] is a character








// 