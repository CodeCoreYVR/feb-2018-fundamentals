// good morning fundamentals!
// javascript

// assembly
// fortran
// cobol
// pascal
// basic
// java
// c
// c++
// c#
// kotlin
// ruby
// python
// ....

// javascript
// it is the only programming language native to our web browser
// web developers
// beginner friendly forgiving

// GOAL: really good fundamentals
// functions
// data structures
// a. arrays
// b. objects

5 + 5; // 10
let result = 5 + 5; // store into memory

let counter = 0;
counter = 1;
counter = 2;

// incrememtation
counter = counter + 1;
counter = counter + 1;

while (true) {
    counter = counter + 1;
}

// loops, gating
// gating == decision
if (true) {
    console.log("Hi!");
}

// true or false
4 < 5; // true
3 === 3; // true
1 > 2; // false
3 != 3; // false

if (age > 18) {
    console.log("I can see Black Panther");
}

while (counter < 10) {
    console.log(counter);
    counter++;
}