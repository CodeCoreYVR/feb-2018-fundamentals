// arrays - list of information
// list of data
// numerically ordered
// indexing or addresses

// shopping lists
// to do lists
// top 10 songs

// names
let name = "Jacob";

// association, they are my names 
let firstName = "Jacob";
let lastName = "Tran";

// list of names using []
let names = ["Jacob", "Tran"];

console.log("My name is " + name);
console.log("My name is " + names);

// names[ address or index ];
// zero-based
// the first item on the list will have an address or index of zero

//  0        1
["Jacob", "Tran"];
names[0]; // "Jacob"
names[1]; // "Tran"

let top10 = [
    "Blackbird", 
    "Because", 
    "Within You", 
    "Hard Days Night", 
    "Revolution",
    "Rocky Raccoon",
    "Billy Jean",
    "God Only Knows",
    "Voodoo Child",
    "Human"
];

// to get "Voodo Child"
top10[8];
top10[10]; // undefined








